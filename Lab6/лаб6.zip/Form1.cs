﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tao.FreeGlut;
using Tao.OpenGl;
using Tao.Platform.Windows;

namespace lr6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            holst.InitializeContexts();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        double cubeX = 0, cubeY = 0, cubeZ = 0;
        double pirX = 0, pirY = 0, pirZ = 0;
        private void cube()
        {

            Gl.glEnable(Gl.GL_BLEND);
            Gl.glEnable(Gl.GL_ALPHA_TEST);
            Gl.glBlendFunc(Gl.GL_SRC_ALPHA, Gl.GL_ONE_MINUS_SRC_ALPHA);

            Gl.glEnable(Gl.GL_DEPTH_TEST);
            Gl.glClear(Gl.GL_DEPTH_BUFFER_BIT);

            Gl.glMatrixMode(Gl.GL_PROJECTION);
            Gl.glLoadIdentity();
            
            Gl.glFrustum(-0.3, 0.3, -0.3, 0.3, 1, 10);
            Gl.glMatrixMode(Gl.GL_MODELVIEW);
            Gl.glLoadIdentity();

            Gl.glTranslated(-0.7, 0.2, -6.0);
            
            Gl.glRotated(cubeX, cubeY, cubeZ, 1);


            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor4d(0, 0.5, 0.1, 0.9);                              
            Gl.glVertex3d(-0.3, 0.3, -0.3);                  
            Gl.glVertex3d(-0.3, -0.3, -0.3);                  
            Gl.glVertex3d(0.3, -0.3, -0.3);                  
            Gl.glVertex3d(0.3, 0.3, -0.3);                
            Gl.glEnd();

            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor4d(1, 0.5, 0, 0.9);                              
            Gl.glVertex3d(-0.3, 0.3, 0.3);                  
            Gl.glVertex3d(-0.3, -0.3, 0.3);                  
            Gl.glVertex3d(0.3, -0.3, 0.3);                  
            Gl.glVertex3d(0.3, 0.3, 0.3);                 
            Gl.glEnd();

            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor4d(0.1, 1, 0.3, 0.9);                              
            Gl.glVertex3d(-0.3, -0.3, -0.3);                  
            Gl.glVertex3d(-0.3, -0.3, 0.3);                 
            Gl.glVertex3d(0.3, -0.3, 0.3);                 
            Gl.glVertex3d(0.3, -0.3, -0.3);                  
            Gl.glEnd();

            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor4d(0.5, 0.2, 1, 0.9);                            
            Gl.glVertex3d(-0.3, 0.3, -0.3);                 
            Gl.glVertex3d(-0.3, 0.3, 0.3);                  
            Gl.glVertex3d(0.3, 0.3, 0.3);             
            Gl.glVertex3d(0.3, 0.3, -0.3);          
            Gl.glEnd();

            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor4d(0.3, 0.4, 0.7, 0.9);                       
            Gl.glVertex3d(-0.3, 0.3, 0.3);              
            Gl.glVertex3d(-0.3, -0.3, 0.3);              
            Gl.glVertex3d(-0.3, -0.3, -0.3);                
            Gl.glVertex3d(-0.3, 0.3, -0.3);                
            Gl.glEnd();

            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor4d(0.0, 0.8, 0.9, 0.9);                         
            Gl.glVertex3d(0.3, 0.3, 0.3);               
            Gl.glVertex3d(0.3, -0.3, 0.3);                 
            Gl.glVertex3d(0.3, -0.3, -0.3);             
            Gl.glVertex3d(0.3, 0.3, -0.3);             
            Gl.glEnd();

            cubeX += 5d;
            cubeY += 5d;
            cubeZ += 40d;
            holst.Invalidate();
        }

        private void piramida()
        {
            Gl.glEnable(Gl.GL_BLEND);
            Gl.glEnable(Gl.GL_ALPHA_TEST);
            Gl.glBlendFunc(Gl.GL_SRC_ALPHA, Gl.GL_ONE_MINUS_SRC_ALPHA);

            Gl.glEnable(Gl.GL_DEPTH_TEST);
            Gl.glClear(Gl.GL_DEPTH_BUFFER_BIT);

            Gl.glMatrixMode(Gl.GL_PROJECTION);
            Gl.glLoadIdentity();
            
            Gl.glFrustum(-0.3, 0.3, -0.3, 0.3, 1, 10);
            Gl.glMatrixMode(Gl.GL_MODELVIEW);
            Gl.glLoadIdentity();

            Gl.glTranslated(0.4, 0.2, -3.0);
            
            Gl.glRotated(pirX, pirY, pirZ, 0.0);

            Gl.glBegin(Gl.GL_QUADS);
            Gl.glColor4d(0, 1, 1, 0.95);
            Gl.glVertex3d(-0.3, -0.3, -0.3);                  
            Gl.glVertex3d(-0.3, -0.3, 0.3);                  
            Gl.glVertex3d(0.3, -0.3, 0.3);                  
            Gl.glVertex3d(0.3, -0.3, -0.3);                  
            Gl.glEnd();

            Gl.glBegin(Gl.GL_TRIANGLES);
            Gl.glColor4d(1, 0.2, 0.5, 0.9);
            Gl.glVertex3d(-0.3, -0.3, -0.3);
            Gl.glVertex3d(-0.3, -0.3, 0.3);
            Gl.glVertex3d(0.0, 0.3, 0);
            Gl.glEnd();

            Gl.glBegin(Gl.GL_TRIANGLES);
            Gl.glColor4d(0.9, 0.9, 0, 0.9);
            Gl.glVertex3d(-0.3, -0.3, 0.3);
            Gl.glVertex3d(0.3, -0.3, 0.3);
            Gl.glVertex3d(0.0, 0.3, 0.0);
            Gl.glEnd();

            Gl.glBegin(Gl.GL_TRIANGLES);
            Gl.glColor4d(0.5, 0.2, 0.2, 0.8); 
            Gl.glVertex3d(0.3, -0.3, 0.3);
            Gl.glVertex3d(0.3, -0.3, -0.3);
            Gl.glVertex3d(0.0, 0.3, 0.0);
            Gl.glEnd();

            Gl.glBegin(Gl.GL_TRIANGLES);
            Gl.glColor4d(0.9, 0.7, 0.7, 0.9);
            Gl.glVertex3d(-0.3, -0.3, -0.3);
            Gl.glVertex3d(0.3, -0.3, -0.3);
            Gl.glVertex3d(0.0, 0.3, 0.0);
            Gl.glEnd();

            pirX += 5d;
            pirY -= 5d;
            pirZ -= 20d;
            holst.Invalidate();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Gl.glViewport(0, 0, holst.Width, holst.Height);
            Gl.glClearColor(1, 1, 1, 1);
            Gl.glClear(Gl.GL_COLOR_BUFFER_BIT);
            cube();
            piramida();
        }

        private void holst_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            timer1.Stop();
            timer1.Enabled = false;
        }

        private void holst_MouseClick(object sender, MouseEventArgs e)
        {
            timer1.Start();
            timer1.Enabled = true;
        }
    }
}
